-------------------------------------------
-- Let�s Perform Some Key SQL Analyses
-------------------------------------------

-- 1. Total Transaction Amount by Customer

SELECT 
    customer_id,
    SUM(tran_amount) AS total_spent
FROM Retail_Data_Transactions
GROUP BY customer_id
ORDER BY total_spent DESC;

-- 2. Join Transactions and Response Data

SELECT 
    t.customer_id,
    FORMAT(t.trans_date, 'yyyy-MM') AS trans_month,
    t.tran_amount,
    r.response
FROM Retail_Data_Transactions t
LEFT JOIN Retail_Data_Response r 
    ON t.customer_id = r.customer_id;

-- 3. Top 10 Customers by Number of Transactions

SELECT TOP 10
    customer_id,
    SUM(tran_amount) AS total_spent
FROM Retail_Data_Transactions
GROUP BY customer_id
ORDER BY total_spent DESC;

-- 4. Customer Count by Response Type

SELECT 
    response,
    COUNT(DISTINCT customer_id) AS customer_count
FROM Retail_Data_Response
GROUP BY response;

-- 5. Monthly Revenue Trend

SELECT 
    FORMAT(trans_date, 'yyyy-MM') AS month,
    SUM(tran_amount) AS monthly_revenue
FROM Retail_Data_Transactions
GROUP BY FORMAT(trans_date, 'yyyy-MM')
ORDER BY month;


-- 6. Average Spend by Response Type

SELECT 
    r.response,
    AVG(t.tran_amount) AS avg_transaction_amount
FROM Retail_Data_Transactions t
JOIN Retail_Data_Response r 
    ON t.customer_id = r.customer_id
GROUP BY r.response;

